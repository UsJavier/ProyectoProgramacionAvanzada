/**
*
*
*@Bryan Us
*/
/*Creo mi interface para mi pila, solo hare el metodo addInicio para ingresar
unicamente y mostrarLista para recorrer mi lista.*/
package proyecto;
public interface Lista{
  public void addInicio(String dato);
}
