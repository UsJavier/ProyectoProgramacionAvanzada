## Proyecto de programacion Avanazada

Este proyecto se debe desarrollar un programa en Java que procese operaciones	aritméticas utilizando	notación polaca	inversa	(RPN Reverse Polish Notation).

[![N|Solid](https://st3.depositphotos.com/1152339/16022/i/1600/depositphotos_160221856-stock-photo-programming-concept-java-on-wall.jpg)](https://es.wikipedia.org/wiki/Notaci%C3%B3n_polaca_inversa)

# Obejetivos
 - El usuario debera podra ingresar operaciones y su resultado de un RPN.
 - El usuario entendera como funciona el algoritmo de este programa.
 - El usuario podra entender que es un RPN .
 
# Reverse Polish Notacion 
Primero definamos que es un RPN, esta breve explicacion esta extendida en el programa y aca puedes acceder al link de la biliografia haciendo click en la imagen de abajo.

![N|Solid](https://www.curiosfera.com/wp-content/uploads/2016/11/Historia-de-los-n%C3%BAmeros.jpg)
 
# Estructura del programa
 El programa esta estructurado de un Nodo que funcionara como almacenamiento para dos interfaces, una pila y otra cola, en las cuales implementan sus metodos de ingreso de datos en la clase principal que es la de RPN. Esta ultima procesa la operacion aritméticas dada la estructura correcta de operacion. 
 
 Puede hacer click aca para ver la estructura [PlantUML](plantuml.svg) 
 
Esto quiere decir si el usuario ingresa una operacion invalida el programa lanzara un mensaje de error mostrando que la operacion se realizara hasta llegar el punto de quiebre o donde no entiende el operador o numbero a procesar. 

[![N|Solid](https://image.ibb.co/n7iwGp/Error.png)]


# Operadores a realizar:

> Plus = +
> Less = -
> Times = *
> Divide = /

Tener en cuenta que los operadores deben ser escritos como lo indica el enunciado, tomar en cuenta que no importa si son ingresados en mayusculas o minisculas, pero que respeten la forma correcta de escribirlos. Caso contrario, se lanzara el error previamente anunciado.

Ejemplo de un RPN

![N|Solid](https://image.ibb.co/cpQbGp/Plus_Less_Times_Divide.png)


### Pantalla

La pantalla mostrara la RPN y una breve explicacion de lo que significa este RPN, adicional mostrara cuantos "tokens" fueron ingresados, es decir cuantos numberos y operadores fueron ingresados; Las operaciones que hizo cada operador aritmético con su resultado y el restultado total.

![N|Solid](https://image.ibb.co/nH0F99/Operacion.png)



**Bryan Javier Us Garica. 10019549**
