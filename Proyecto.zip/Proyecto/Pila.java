/**
*
*
*@Bryan Us
*/
/*Creo mi interface para mi pila, solo hare el metodo push para ingresar
unicamente, ya que sera el unico que utilice*/
package proyecto;
public interface Pila{
  public void push(double valor);
}
